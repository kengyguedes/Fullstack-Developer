package com.maxima.maxWebApplication

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MaxWebApplicationTests {

	@Test
	fun contextLoads() {
	}

}
